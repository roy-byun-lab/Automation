import os
import shutil

def organize_files(directory):
    if not os.path.exists(directory):
        print(f"Path does not exist: {directory}")
        return

    # List up files in the specified directory
    for filename in os.listdir(directory):
        file_path = os.path.join(directory, filename)

        # Check if it's a file
        if os.path.isfile(file_path):
            # Get the file extension
            _, file_extension = os.path.splitext(filename)
            if not file_extension:
                file_extension = "Others"
            else:
                file_extension = file_extension[1:]  # Remove the dot (.)

            # Create a folder for the file extension if it doesn't exist
            extention_folder = os.path.join(directory, file_extension)
            if not os.path.exists(extention_folder):
                os.makedirs(extention_folder)

            # Move the file to the corresponding folder
            shutil.move(file_path, os.path.join(extention_folder, filename))
            print(f"Moved: {filename} -> {os.path.join(extention_folder, filename)}")

if __name__ == "__main__":
    target_folder = input("フォルダーPathを入力してください。").strip()
    organize_files(target_folder)