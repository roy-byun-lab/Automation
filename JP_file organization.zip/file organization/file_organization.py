import os
import shutil

def organize_files(directory):
    # 指定されたディレクトリ内のファイルをリストアップ
    for filename in os.listdir(directory):
        file_path = os.path.join(directory, filename)
        
        # ファイルかディレクトリかを確認
        if os.path.isfile(file_path):
            # ファイルの拡張子を取得
            file_extension = filename.split('.')[-1].lower()
            
            # 拡張子に基づいて移動先のフォルダを決定
            if file_extension in ['jpg', 'jpeg', 'png', 'gif']:
                folder_name = 'Images'
            elif file_extension in ['txt', 'pdf', 'docx']:
                folder_name = 'Documents'
            elif file_extension in ['indd']:
                folder_name = '定義ファイル'
            elif file_extension in ['json']:
                folder_name = 'json'
            elif file_extension in ['jsx']:
                folder_name = 'jsx'
            # elif file_extension in ['拡張子1', '拡張子2']:
            #     folder_name = 'フォルダー名'
            else:
                folder_name = 'Others'
            
            # 新しいフォルダのパスを作成
            folder_path = os.path.join(directory, folder_name)
            
            # フォルダが存在しない場合は作成
            if not os.path.exists(folder_path):
                os.makedirs(folder_path)
            
            # ファイルを移動
            new_file_path = os.path.join(folder_path, filename)
            shutil.move(file_path, new_file_path)
            print(f"Moved: {filename} -> {folder_name}")

if __name__=="__main__":
    target_folder = input("フォルダーPathを入力してください。").strip()
    organize_files(target_folder)
